/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.SaldoInsuficienteException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Maria
 */
public abstract class Cuenta implements Serializable {
    private int numero; 
    private transient String titular; // No serializable por seguridad
    private double saldo;
    private double saldoMinimo;
    private Date fechaApertura;

    public Cuenta(int numero, String titular, double saldo, double saldoMinimo, Date fechaApertura) throws SaldoInsuficienteException {
        this.numero = numero;
        this.titular = titular;
        if(saldo < saldoMinimo){
            throw new SaldoInsuficienteException("El saldo no puede ser menor que el saldo mínimo de: " + saldoMinimo);
           
        }
        this.saldo = saldo;
        this.saldoMinimo = saldoMinimo;
        this.fechaApertura = fechaApertura;
    }
    
      // Método para modificar el saldo
    public void setSaldo(double saldo) throws SaldoInsuficienteException {
        if (saldo < saldoMinimo) {
            throw new SaldoInsuficienteException("El saldo no puede ser menor que el saldo mínimo de: " + saldoMinimo);
        }
        this.saldo = saldo; // Establece el saldo si es válido
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getSaldoMinimo() {
        return saldoMinimo;
    }

    public void setSaldoMinimo(double saldoMinimo) {
        this.saldoMinimo = saldoMinimo;
    }

    public Date getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(Date fechaApertura) {
        this.fechaApertura = fechaApertura;
    }
    
    // Método para verificar si el saldo es inferior al saldo mínimo
    public void verificarSaldo() throws SaldoInsuficienteException {
        if (this.saldo < this.saldoMinimo) {
            throw new SaldoInsuficienteException("El saldo es inferior al saldo mínimo permitido.");
        }
    }
    
    
    // Método abstracto que será implementado por las subclases
    public abstract void calcular();

    
    

    
}
