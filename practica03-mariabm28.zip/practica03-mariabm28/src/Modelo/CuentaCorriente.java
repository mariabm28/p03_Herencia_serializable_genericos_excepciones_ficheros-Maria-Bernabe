/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.SaldoInsuficienteException;
import static Modelo.CalcularFecha.dia;
import static Modelo.CalcularFecha.mes;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Maria
 */
public class CuentaCorriente extends Cuenta implements CalcularFecha {
    
    private double comisionMantenimiento;
    private String tipoComision;
    private Date ultimaFechaCalculo;

    public CuentaCorriente(int numero, String titular, double saldo, double saldoMinimo, Date fechaApertura, double comisionMantenimiento, String tipoComision) throws SaldoInsuficienteException {
        super(numero, titular, saldo, saldoMinimo, fechaApertura);
        this.comisionMantenimiento = comisionMantenimiento;
        this.tipoComision = tipoComision;
        this.ultimaFechaCalculo=fechaApertura;
    }

   
    public double getComisionMantenimiento() {
        return comisionMantenimiento;
    }

    public void setComisionMantenimiento(double comisionMantenimiento) {
        this.comisionMantenimiento = comisionMantenimiento;
    }

    public String getTipoComision() {
        return tipoComision;
    }

    public void setTipoComision(String tipoComision) {
        this.tipoComision = tipoComision;
    }

    public Date getUltimaFechaCalculo() {
        return ultimaFechaCalculo;
    }

    public void setUltimaFechaCalculo(Date ultimaFechaCalculo) {
        this.ultimaFechaCalculo = ultimaFechaCalculo;
    }

    

    @Override
    public void calcular() {
        try {
            // Descontamos la comisión
            setSaldo(getSaldo() - comisionMantenimiento);
        } catch (SaldoInsuficienteException ex) {
            Logger.getLogger(CuentaCorriente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    @Override
    public boolean haPasadoUnMes(Date fechaApertura){
        
        // Instancia de Calendar para fecha de apertura
        Calendar apertura = Calendar.getInstance();
        apertura.setTime(fechaApertura); // Obtener el tiempo de la fecha de apertura

        // Instancia de Calendar para fecha actual
        Calendar actual = Calendar.getInstance();

        // Obtener los valores del día y del mes
        int diaApertura = apertura.get(dia);
        int mesApertura = apertura.get(mes);
        
        int diaActual = actual.get(dia);
        int mesActual = actual.get(mes);

        // Comprobar si se ha cumplido un mes
        if ((mesActual > mesApertura  && diaActual >= diaApertura)) {
            return true; // Se cumplió un mes
        } else {
            return false; // No se cumplió un mes
        }
    }
    
    public int mesesTranscurridos(Date fecha) {
        Calendar fechaUltimoCalculo = Calendar.getInstance();
        fechaUltimoCalculo.setTime(this.ultimaFechaCalculo);

        Calendar fechaActual = Calendar.getInstance();
        fechaActual.setTime(fecha);

        int anios = fechaActual.get(Calendar.YEAR) - fechaUltimoCalculo.get(Calendar.YEAR);
        int meses = fechaActual.get(Calendar.MONTH) - fechaUltimoCalculo.get(Calendar.MONTH);

        return anios * 12 + meses+1;
    }
    

        
        

    @Override
    public boolean haPasadoUnAnio(Date fechaApertura) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        
    

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaFormateada = sdf.format(this.getFechaApertura());
        
        return "Es una cuenta corriente: " 
                + "  numero=" + this.getNumero() +
                "  ||  titular=" + this.getTitular() +
                "  ||  saldo=" + this.getSaldo() +
                "  ||  saldoMinimo=" + this.getSaldoMinimo() +
                "  ||  fechaApertura=" + fechaFormateada + 
                "  ||  comisionMantenimiento=" + comisionMantenimiento + 
                "  ||  tipoComision=" + tipoComision;
    }

 
    
}
