/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.SaldoInsuficienteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Maria
 */
public class CuentaAhorro extends Cuenta implements CalcularFecha {
    
    private double interesAnual;
    private int plazo; //años que tienen que pasar para poder utilizar el dinero de la cuenta
    private Date ultimaFechaCalculo;

    public CuentaAhorro(int numero, String titular, double saldo, double saldoMinimo, Date fechaApertura, double interesAnual, int plazo) throws SaldoInsuficienteException {
        super(numero, titular, saldo, saldoMinimo, fechaApertura);
        this.interesAnual = interesAnual;
        this.plazo = plazo;
        this.ultimaFechaCalculo=fechaApertura;
    }

    public double getInteresAnual() {
        return interesAnual;
    }

    public void setInteresAnual(double interesAnual) {
        this.interesAnual = interesAnual;
    }

    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }

    public Date getUltimaFechaCalculo() {
        return ultimaFechaCalculo;
    }

    public void setUltimaFechaCalculo(Date ultimaFechaCalculo) {
        this.ultimaFechaCalculo = ultimaFechaCalculo;
    }
    

    @Override
    public void calcular() {
        try {
            // Cálculo de interés
            double interes = getSaldo() * (interesAnual / 100);
            setSaldo(getSaldo() + interes); // Actualizamos el saldo
        } catch (SaldoInsuficienteException ex) {
            Logger.getLogger(CuentaAhorro.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
    @Override
    public boolean haPasadoUnAnio (Date fechaApertura){
        
        Calendar apertura = Calendar.getInstance();
        apertura.setTime(fechaApertura);

        Calendar actual = Calendar.getInstance();

        // Comparar año utilizando las constantes de la interfaz
        return (actual.get(anio) > apertura.get(anio) && actual.get(mes) >= apertura.get(mes) && actual.get(dia) >= apertura.get(dia));
    }
    
    public int aniosTranscurridos(Date fecha) {
        Calendar fechaUltimoCalculo = Calendar.getInstance();
        fechaUltimoCalculo.setTime(this.ultimaFechaCalculo);
    
        Calendar fechaActual = Calendar.getInstance();
        fechaActual.setTime(fecha);
    
        return fechaActual.get(anio) - fechaUltimoCalculo.get(anio); 
    }
        
     

    @Override
    public boolean haPasadoUnMes(Date fechaApertura) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    

    @Override
    public String toString() {
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaFormateada = sdf.format(this.getFechaApertura());
         return  "Es una cuenta de ahorro: " 
                + "  numero=" + this.getNumero() +
                "  ||  titular=" + this.getTitular() +
                "  ||  saldo=" + this.getSaldo() +
                "  ||  saldoMinimo=" + this.getSaldoMinimo() +
                "  ||  fechaApertura=" + fechaFormateada +
                "  ||  interesAnual=" + interesAnual + 
                "  || plazo=" + plazo ;
    }

  
    
    
}
