/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelo;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Maria
 */
public interface CalcularFecha {
    int dia=Calendar.DAY_OF_MONTH;
    int mes=Calendar.MONTH;
    int anio=Calendar.YEAR;
    
    boolean haPasadoUnMes(Date fechaApertura);
           
    boolean haPasadoUnAnio(Date fechaApertura);
    
}
