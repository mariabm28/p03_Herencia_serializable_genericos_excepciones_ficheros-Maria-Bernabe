/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.Lista;
import Controlador.Nodo;
import Modelo.Cuenta;
import Modelo.CuentaAhorro;
import Modelo.CuentaCorriente;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Maria
 */
public class PanelVisual extends JPanel {
    
    private JList<String> listaVisualizacion; // JList para mostrar los elementos
    private DefaultListModel<String> modeloLista; // Modelo para la JList
    /*DefaultListModel<String> es una implementación de la interfaz ListModel, que se utiliza 
    para almacenar los datos que serán mostrados en un componente de tipo JList
    JList no almacena directamente los datos; en su lugar, se vincula con un modelo, que en este 
    caso es un DefaultListModel. El modelo gestiona los datos, y la JList simplemente los presenta*/
    private Lista<Cuenta> listaCuentas; // Lista genérica de cuentas
    

    public PanelVisual(Lista<Cuenta> listaCuentas ) {
        this.listaCuentas = listaCuentas;
        
        setLayout(new BorderLayout());

        // Inicializamos el modelo de la lista
        modeloLista = new DefaultListModel<>();
        listaVisualizacion = new JList<>(modeloLista);
        
        // Añadimos la lista dentro de un JScrollPane para poder desplazar
        JScrollPane scrollPane = new JScrollPane(listaVisualizacion);
        add(scrollPane, BorderLayout.CENTER);
        /*JScrollPane es un contenedor que permite añadir barras de desplazamiento (scroll) 
        a otro componente, en este caso, a una JList.Si tienes una lista larga de cuentas, 
        es posible que todas ellas no quepan dentro del espacio visible en la ventana de 
        la aplicación. El JScrollPane permite agregar barras de desplazamiento automáticamente 
        si la lista de elementos es más larga o ancha que el espacio disponible.*/

        // Llenar la lista con los datos
        cargarLista(listaCuentas);
        
    }
    
     // Método para vaciar la lista de cuentas y la lista visual
    public void vaciarLista() {
        listaCuentas.vaciar(); // Vaciar la lista de cuentas 
        modeloLista.clear(); // Limpiar el modelo de la JList
        listaVisualizacion.updateUI(); // Actualizar la UI
    }

    // Método para cargar la lista con los datos y el tipo de cuenta
    void cargarLista(Lista<Cuenta> listaCuentas) {
        
        
        modeloLista.clear(); // Limpiar la lista antes de agregar nuevos elementos

        Nodo<Cuenta> nodoActual = listaCuentas.getInicio(); // Obtener el primer nodo de la lista
        while (nodoActual != null) {
            Cuenta cuentaActual = nodoActual.getDato(); // Obtener el dato del nodo actual
            if (cuentaActual != null) {
                modeloLista.addElement(cuentaActual.toString()); // Añadir a la lista visual
            }
            nodoActual = nodoActual.getSiguiente(); // Avanzar al siguiente nodo
        }

        listaVisualizacion.updateUI(); // Asegurarnos de que la UI se actualiza
    }
     // Método para actualizar el JList con la cuenta actual
    private void actualizarListaConActual() {
        Nodo<Cuenta> nodoActual = listaCuentas.getInicio();  // Obtener el primer nodo
       modeloLista.clear();  // Limpiar el modelo de la JList

       // Recorremos la lista desde el inicio hasta el final
        while (nodoActual != null) {
            Cuenta cuenta = nodoActual.getDato();  // Obtener la cuenta desde el nodo
            String tipoCuenta = null;
    
            // Determinamos si es cuenta de ahorro o cuenta corriente
            if (cuenta instanceof CuentaAhorro) {
                tipoCuenta = "Cuenta Ahorro";
            } else if (cuenta instanceof CuentaCorriente) {
                tipoCuenta = "Cuenta Corriente";
            } 
            // Formatear la información de la cuenta
            String infoCuenta = "Número: " + cuenta.getNumero() + ", Titular: " + cuenta.getTitular() + " (" + tipoCuenta + ")";

            // Añadir la información al modelo de la JList
            modeloLista.addElement(infoCuenta);

            // Avanzar al siguiente nodo
            nodoActual = nodoActual.getSiguiente();
        } 
     
    }    
    
    
    
    public void actualizarLista() {
        cargarLista(listaCuentas); 
    } 
    

       

    public Lista<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public void setListaCuentas(Lista<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;
    }
    
}   