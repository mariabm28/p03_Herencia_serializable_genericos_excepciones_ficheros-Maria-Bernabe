/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.Lista;
import Controlador.Nodo;
import Controlador.SaldoInsuficienteException;
import Modelo.Cuenta;
import Modelo.CuentaAhorro;
import Modelo.CuentaCorriente;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Maria
 */

public class PanelUnoaUno extends JPanel {
    private Lista<Cuenta> listaCuentas;  // Lista genérica de cuentas
    private JTextField txtTipoCuenta, txtNumero, txtTitular, txtSaldo, txtSaldoMinimo, txtFechaApertura, txtComision, txtInteres, txtTipoComi, txtPlazo;
    private JButton btnAvanzar, btnRetroceder, btnCalcular;
    private JLabel lblTipoCuenta, lblNumero, lblTitular, lblSaldo, lblSaldoMinimo, lblFechaApertura, lblComision, lblInteres, lblTipoComi, lblPlazo;

    public PanelUnoaUno(Lista<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;

        setLayout(new GridLayout(13, 2)); // Definir un layout en una cuadrícula de 8 filas y 2 columnas
        
        // Inicializamos los componentes
        lblTipoCuenta = new JLabel("Tipo de cuenta:");
        txtTipoCuenta = new JTextField();
        txtTipoCuenta.setEditable(false);
        
        
        lblNumero = new JLabel("Número de Cuenta:");
        txtNumero = new JTextField();
        txtNumero.setEditable(false); // No editable porque es sólo visualización
        
        lblTitular = new JLabel("Titular:");
        txtTitular = new JTextField();
        txtTitular.setEditable(false);
        
        lblSaldo = new JLabel("Saldo:");
        txtSaldo = new JTextField();
        txtSaldo.setEditable(false);
        
        lblSaldoMinimo = new JLabel("Saldo Mínimo:");
        txtSaldoMinimo = new JTextField();
        txtSaldoMinimo.setEditable(false);
        
        lblFechaApertura = new JLabel("Fecha de Apertura:");
        txtFechaApertura = new JTextField();
        txtFechaApertura.setEditable(false);
        
        lblComision = new JLabel("Comisión:");
        txtComision = new JTextField();
        txtComision.setEditable(false);
        
        lblTipoComi = new JLabel("Tipo de comision:");
        txtTipoComi = new JTextField();
        txtTipoComi.setEditable(false);
        
        lblInteres = new JLabel("Interes:");
        txtInteres = new JTextField();
        txtInteres.setEditable(false);
        
        lblTipoComi = new JLabel("Tipo de comision:");
        txtTipoComi = new JTextField();
        txtTipoComi.setEditable(false);
        
        lblPlazo = new JLabel("Plazo:");
        txtPlazo = new JTextField();
        txtPlazo.setEditable(false);
        
        

        // Botones
        btnAvanzar = new JButton("Avanzar");
        btnRetroceder = new JButton("Retroceder");
        btnCalcular = new JButton("Calcular");

        // Añadir componentes al panel
        add(lblTipoCuenta); add(txtTipoCuenta);
        add(lblNumero); add(txtNumero);
        add(lblTitular); add(txtTitular);
        add(lblSaldo); add(txtSaldo);
        add(lblSaldoMinimo); add(txtSaldoMinimo);
        add(lblFechaApertura); add(txtFechaApertura);
        add(lblComision); add(txtComision);
        add(lblTipoComi);add(txtTipoComi);
        add(lblInteres);add(txtInteres);
        add(lblPlazo);add(txtPlazo);
        
        add(btnRetroceder); add(btnAvanzar);
        add(btnCalcular); // Espacio vacío para alinear los botones
        
         
        /*
        // Inicializar la lista en el primer elemento
        if (!listaCuentas.esVacia()) {
            listaCuentas.lista();
            actualizarPantalla();
            actualizarBotones();
        }*/

        // Listeners para los botones
        btnAvanzar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listaCuentas.avanzar(); // Avanzar al siguiente nodo
                actualizarPantalla();   // Actualizar la vista
                actualizarBotones();
            }
        });

        btnRetroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listaCuentas.retroceder(); // Retroceder al nodo anterior
                actualizarPantalla();      // Actualizar la vista
                actualizarBotones();
            }
        });

        btnCalcular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcularYActualizarSaldo(); // Llamar al método de cálculo según el tipo de cuenta
                actualizarBotones();
            }
        });

       
    }

    // Método para actualizar la pantalla con los datos de la cuenta actual
    void actualizarPantalla() {
        Cuenta cuenta = listaCuentas.leer();
        
        //System.out.println("Cuenta actual: " + listaCuentas.leer());
        
        if (cuenta != null) {
            txtNumero.setText(String.valueOf(cuenta.getNumero()));
            txtTitular.setText(cuenta.getTitular());
            txtSaldo.setText(String.valueOf(cuenta.getSaldo()));
            txtSaldoMinimo.setText(String.valueOf(cuenta.getSaldoMinimo()));
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            txtFechaApertura.setText(sdf.format(cuenta.getFechaApertura().getTime()));

            // Si es una cuenta de ahorro o corriente, mostrar la información extra (interés o comisión)
            if (cuenta instanceof CuentaAhorro) {
                CuentaAhorro cuentaAhorro = (CuentaAhorro) cuenta;
                txtTipoCuenta.setText("Cuenta de ahorro");
                txtInteres.setText( String.valueOf(cuentaAhorro.getInteresAnual()));
                txtPlazo.setText( String.valueOf(cuentaAhorro.getPlazo()));
                txtInteres.setVisible(true);
                txtPlazo.setVisible(true);
                txtComision.setVisible(false);
                txtTipoComi.setVisible(false);
            } else if (cuenta instanceof CuentaCorriente) {
                CuentaCorriente cuentaCorriente = (CuentaCorriente) cuenta;
                txtTipoCuenta.setText("Cuenta corriente");
                txtComision.setText( String.valueOf(cuentaCorriente.getComisionMantenimiento()));
                txtTipoComi.setText( cuentaCorriente.getTipoComision());
                txtComision.setVisible(true);
                txtTipoComi.setVisible(true);
                txtInteres.setVisible(false);
                txtPlazo.setVisible(false);
                
            }
          
        }

       
    }
    

    // Método para calcular y actualizar el saldo de la cuenta actual
    private void calcularYActualizarSaldo() {
        
         Cuenta cuentaActual = listaCuentas.leer(); // Obtener la cuenta actual de la lista
        if (cuentaActual != null) {
            try {
                // Verificamos si ha pasado un mes o un año
                Date fechaApertura = cuentaActual.getFechaApertura(); // Obtener fecha de apertura
                Date fechaActual= new Date();
                if (cuentaActual instanceof CuentaAhorro) {
                    
                    // Si es una cuenta de ahorro, calcular el interés
                    CuentaAhorro cuentaAhorro = (CuentaAhorro) cuentaActual; // Convertir a CuentaAhorro
                    
                    
                    if (cuentaAhorro.haPasadoUnAnio(fechaApertura)) {
                        
                            // Cálculo de interés
                            double interes = cuentaAhorro.getSaldo() * (cuentaAhorro.getInteresAnual() / 100);
                            cuentaAhorro.setSaldo(cuentaAhorro.getSaldo()+ interes); // Actualizamos el saldo

                            //cuentaAhorro.calcular(); // Llamar al método calcular de CuentaAhorro
                            actualizarPantalla(); // Actualizamos los campos en pantalla
                            
                         /*   // Verificar si el saldo alcanzó el saldo mínimo
                        if (cuentaAhorro.getSaldo() <= cuentaAhorro.getSaldoMinimo()) {
                            cuentaAhorro.setUltimaFechaCalculo(fechaActual);
                            actualizarBotones();
                            JOptionPane.showMessageDialog(this, "El saldo ha alcanzado el mínimo permitido.");
                            return;  // Detener el cálculo
                         }*/
                    
                                            
                        cuentaAhorro.setUltimaFechaCalculo(fechaActual);// Actualizar la última fecha de cálculo
                         
                    } else {
                        JOptionPane.showMessageDialog(this, "No ha pasado el periodo requerido para calcular el interés.");
                        return;
                    }
                } else if (cuentaActual instanceof CuentaCorriente) {
                    // Si es una cuenta corriente, descontar la comisión
                    CuentaCorriente cuentaCorriente = (CuentaCorriente) cuentaActual; // Convertir a CuentaCorriente
                    
                    
                    if (cuentaCorriente.haPasadoUnMes(fechaApertura)) {
                           
                            cuentaCorriente.setSaldo(cuentaCorriente.getSaldo() - cuentaCorriente.getComisionMantenimiento()); // Actualizamos el saldo
                            //cuentaCorriente.calcular(); // Llamar al método calcular de CuentaCorriente
                            actualizarPantalla(); // Actualizamos los campos en pantalla
                         
                            // Verificar si el saldo alcanzó el saldo mínimo
                     /*    if (cuentaCorriente.getSaldo() < cuentaCorriente.getSaldoMinimo()) {
                             cuentaCorriente.setUltimaFechaCalculo(fechaActual);
                             btnCalcular.setEnabled(false);
                             actualizarBotones();
                            JOptionPane.showMessageDialog(this, "El saldo ha alcanzado el mínimo permitido.");
                            return;  // Detener el cálculo
                         }*/
                         
                        cuentaCorriente.setUltimaFechaCalculo(fechaActual);
                    } else {
                        btnCalcular.setEnabled(false);
                        JOptionPane.showMessageDialog(this, "No ha pasado el periodo requerido para calcular la comisión.");
                        return;
                    }
                }
                
                // Verificamos que el saldo no sea menor que el saldo mínimo
                if (cuentaActual.getSaldo() < cuentaActual.getSaldoMinimo()) {
                    throw new SaldoInsuficienteException("El saldo no puede ser inferior al saldo mínimo.");
                }

                actualizarBotones();
                  
            
            } catch (SaldoInsuficienteException ex) {
            // Manejar la excepción personalizada para saldo insuficiente
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de saldo", JOptionPane.ERROR_MESSAGE);
              
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "No hay cuenta seleccionada.");
        }
   }
    public void vaciarLista() {
        listaCuentas.vaciar(); 
        txtTipoCuenta.setText("");
        txtNumero.setText("");
        txtTitular.setText("");
        txtSaldo.setText("");
        txtSaldoMinimo.setText("");
        txtFechaApertura.setText("");
        txtComision.setText("");
        txtInteres.setText("");
        txtTipoComi.setText("");
        txtPlazo.setText("");
     
    }
    
    
     
    

    // Método para habilitar/deshabilitar botones según la situación de la lista
    void actualizarBotones() {
        btnRetroceder.setEnabled(!listaCuentas.esPrimero());
        btnAvanzar.setEnabled(!listaCuentas.esUltimo());
        
        Cuenta cuentaActual = listaCuentas.leer();
         // Desactivamos el botón por defecto
            btnCalcular.setEnabled(false);
        if(cuentaActual!=null)   { 
            // Validamos si se cumple la condición para habilitar el botón
            Date fechaApertura = cuentaActual.getFechaApertura();
            if (cuentaActual instanceof CuentaAhorro) {
                CuentaAhorro cuentaAhorro = (CuentaAhorro) cuentaActual;
                if (cuentaAhorro.haPasadoUnAnio(fechaApertura)) {
                    btnCalcular.setEnabled(true);
                }
            } else if (cuentaActual instanceof CuentaCorriente) {
                CuentaCorriente cuentaCorriente = (CuentaCorriente) cuentaActual;
                if (cuentaCorriente.haPasadoUnMes(fechaApertura)) {
                    btnCalcular.setEnabled(true);
                }
            }
        }    
    }

    public Lista<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public void setListaCuentas(Lista<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;  
        this.listaCuentas.lista(); // Reinicia el nodo actual al inicio
        actualizarPantalla();  // Actualiza la visualización
        actualizarBotones(); // Actualiza los botones
    }
}






