/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.FechaFuturaException;
import Controlador.Lista;
import Controlador.SaldoInsuficienteException;
import Modelo.Cuenta;
import Modelo.CuentaAhorro;
import Modelo.CuentaCorriente;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Maria
 */

public class PanelInsercion extends JPanel {

    private JTextField campoNumeroCuenta;
    private JTextField campoTitular;
    private JTextField campoSaldo;
    private JTextField campoSaldoMinimo;  
    private JTextField campoInteresAnual;  // Campo específico para Cuenta Ahorro
    private JTextField campoPlazo;          // Campo específico para Cuenta Ahorro
    private JTextField campoComision;       // Campo específico para Cuenta Corriente
    private JTextField campoTipoComision;   // Campo específico para Cuenta Corriente
    private JTextField campoFechaApertura;  // Campo para la fecha de apertura
    private JButton botonInsertar;
    private JRadioButton botonCuentaAhorro;
    private JRadioButton botonCuentaCorriente;
    private Lista<Cuenta> listaCuentas;
    private JPanel panelTipoCuenta;         // Panel para seleccionar tipo de cuenta
    private JPanel panelCampos;              // Panel para campos de la cuenta
    
    private PanelVisual panelVisual;

    public PanelInsercion(Lista<Cuenta> listaCuentas, PanelVisual panelVisual) {
        this.listaCuentas = listaCuentas;
        this.panelVisual=panelVisual;

        
        setLayout(new BorderLayout());

        // Panel para seleccionar el tipo de cuenta
        panelTipoCuenta = new JPanel();
        botonCuentaAhorro = new JRadioButton("Cuenta de Ahorro");
        botonCuentaCorriente = new JRadioButton("Cuenta Corriente");

        ButtonGroup grupoBotones = new ButtonGroup();
        grupoBotones.add(botonCuentaAhorro);
        grupoBotones.add(botonCuentaCorriente);

        panelTipoCuenta.add(botonCuentaAhorro);
        panelTipoCuenta.add(botonCuentaCorriente);
        add(panelTipoCuenta, BorderLayout.NORTH);

        // Panel para campos de la cuenta
        panelCampos = new JPanel();
        panelCampos.setLayout(new GridLayout(9, 2)); 
        add(panelCampos, BorderLayout.CENTER);

        // Etiquetas y campos de texto para los datos de la cuenta
        panelCampos.add(new JLabel("Número de Cuenta:"));
        campoNumeroCuenta = new JTextField();
        panelCampos.add(campoNumeroCuenta);

        panelCampos.add(new JLabel("Titular:"));
        campoTitular = new JTextField();
        panelCampos.add(campoTitular);

        panelCampos.add(new JLabel("Saldo:"));
        campoSaldo = new JTextField();
        panelCampos.add(campoSaldo);

        panelCampos.add(new JLabel("Saldo Mínimo:"));
        campoSaldoMinimo = new JTextField();
        panelCampos.add(campoSaldoMinimo);

        panelCampos.add(new JLabel("Fecha de Apertura:"));
        campoFechaApertura = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        panelCampos.add(campoFechaApertura);

        // Campos específicos para Cuenta de Ahorro
        panelCampos.add(new JLabel("Interés Anual:"));
        campoInteresAnual = new JTextField();
        panelCampos.add(campoInteresAnual);

        panelCampos.add(new JLabel("Plazo:"));
        campoPlazo = new JTextField();
        panelCampos.add(campoPlazo);

        // Campos específicos para Cuenta Corriente
        panelCampos.add(new JLabel("Comisión Mantenimiento:"));
        campoComision = new JTextField();
        panelCampos.add(campoComision);

        panelCampos.add(new JLabel("Tipo de Comisión:"));
        campoTipoComision = new JTextField();
        panelCampos.add(campoTipoComision);

        // Botón para insertar la nueva cuenta
        botonInsertar = new JButton("Insertar");
        add(botonInsertar, BorderLayout.SOUTH);

        // Asignar evento al botón
        botonInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertarCuenta();
            }
        });

        // Escuchar cambios en la selección de tipo de cuenta
        botonCuentaAhorro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 mostrarCamposCuentaAhorro();
            }     
        });    
        botonCuentaCorriente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 mostrarCamposCuentaCorriente();
            }     
        });  
               

        // Inicializar el panel ocultando los campos específicos
        ocultarCamposEspecificos();
    }

    // Método para mostrar campos específicos de Cuenta de Ahorro
    private void mostrarCamposCuentaAhorro() {
        campoInteresAnual.setVisible(true);
        campoPlazo.setVisible(true);
        campoComision.setVisible(false);
        campoTipoComision.setVisible(false);
        panelCampos.revalidate(); // Actualizar el panel
        panelCampos.repaint();     // Repaint para reflejar los cambios
    }

    // Método para mostrar campos específicos de Cuenta Corriente
    private void mostrarCamposCuentaCorriente() {
        campoInteresAnual.setVisible(false);
        campoPlazo.setVisible(false);
        campoComision.setVisible(true);
        campoTipoComision.setVisible(true);
        panelCampos.revalidate(); // Actualizar el panel
        panelCampos.repaint();     // Repaint para reflejar los cambios
    }

    // Método para ocultar campos específicos al inicio
    private void ocultarCamposEspecificos() {
        campoInteresAnual.setVisible(false);
        campoPlazo.setVisible(false);
        campoComision.setVisible(false);
        campoTipoComision.setVisible(false);
    }

    // Método para insertar una nueva cuenta
    private Cuenta insertarCuenta() {
        String numeroCuenta = campoNumeroCuenta.getText();
        String titular = campoTitular.getText();
        String saldo = campoSaldo.getText();
        String saldoMinimo = campoSaldoMinimo.getText();
        String interesAnual = campoInteresAnual.getText();
        String plazo = campoPlazo.getText();
        String comision = campoComision.getText();
        String tipoComision = campoTipoComision.getText();
        String fechaApertura = campoFechaApertura.getText();

        if (validarCampos(numeroCuenta, titular, saldo, saldoMinimo, fechaApertura)) {
            try {
                int numCuenta = Integer.parseInt(numeroCuenta);
                double saldoInicial = Double.parseDouble(saldo);
                double saldoMin = Double.parseDouble(saldoMinimo);
                Date fecha = new SimpleDateFormat("yyyy-MM-dd").parse(fechaApertura);

                // Validar que la fecha de apertura no sea futura
                if (FechaFuturaException.esFechaFutura(fecha)) {
                    throw new FechaFuturaException ("La fecha de apertura no puede ser futura");
                    
                }

                // Validar saldo inicial
                if (saldoInicial < saldoMin) {
                    throw new SaldoInsuficienteException("El saldo inicial no puede ser menor al saldo mínimo.");
                }

                // Crear la cuenta según el tipo
                Cuenta nuevaCuenta;
                if (botonCuentaAhorro.isSelected()) {
                    double interes = Double.parseDouble(interesAnual);
                    int plazoInt = Integer.parseInt(plazo);
                    nuevaCuenta = new CuentaAhorro(numCuenta, titular, saldoInicial, saldoMin, fecha, interes, plazoInt);
                } else {
                    double comisionMensual = Double.parseDouble(comision);
                    String tipoCom = tipoComision;
                    nuevaCuenta = new CuentaCorriente(numCuenta, titular, saldoInicial, saldoMin, fecha, comisionMensual, tipoCom);
                }

                listaCuentas.insertar(nuevaCuenta);
                panelVisual.actualizarLista();
                
                JOptionPane.showMessageDialog(this, "Cuenta insertada correctamente: " );
                
                // Limpiar campos después de insertar
                limpiarCampos();
                return nuevaCuenta; // Retornar la cuenta insertada
               
            } catch (SaldoInsuficienteException ex) {
                // Manejar la excepción de saldo insuficiente
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de saldo", JOptionPane.ERROR_MESSAGE);
            } catch (FechaFuturaException ex) {
                // Manejar la excepción de saldo insuficiente
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error de fecha", JOptionPane.ERROR_MESSAGE);    
        
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error en formato: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Datos inválidos, por favor verifica.");
        }
        return null; // Retornar null si hubo error
    }

    // Método para validar los campos ingresados
    private boolean validarCampos(String numeroCuenta, String titular, String saldo, String saldoMinimo, String fechaApertura) {
        try {
            int numCuenta = Integer.parseInt(numeroCuenta);
            double saldoCuenta = Double.parseDouble(saldo);
            double saldoMin = Double.parseDouble(saldoMinimo);

            // Validar que el número de cuenta sea positivo y que el titular no esté vacío
            if (numCuenta <= 0 || titular.isEmpty()) {
                return false;
            }

            // Validar que el saldo sea mayor o igual a cero 
            if (saldoCuenta < 0) {
                return false;
            }

            
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Método para limpiar los campos después de insertar una cuenta
    private void limpiarCampos() {
        campoNumeroCuenta.setText("");
        campoTitular.setText("");
        campoSaldo.setText("");
        campoSaldoMinimo.setText("");
        campoInteresAnual.setText("");
        campoPlazo.setText("");
        campoComision.setText("");
        campoTipoComision.setText("");
        campoFechaApertura.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date())); // Resetear a la fecha actual

        // Resetear selección de tipo de cuenta
        botonCuentaAhorro.setSelected(false);
        botonCuentaCorriente.setSelected(false);

        // Ocultar campos específicos al inicio
        ocultarCamposEspecificos();
    }
    
}    

