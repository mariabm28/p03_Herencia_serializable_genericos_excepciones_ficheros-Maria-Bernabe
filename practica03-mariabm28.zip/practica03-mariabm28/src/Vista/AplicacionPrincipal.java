/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;
import Controlador.GestorArchivos;
import Controlador.Lista;
import Modelo.Cuenta;
import Modelo.CuentaAhorro;
import Modelo.CuentaCorriente;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Maria
 */

public class AplicacionPrincipal extends JFrame {
    
    private static JPanel panelPrinci;
    private JMenuBar menuBar; // Barra de menú
    private JMenu menu; // Menú principal
    private JMenu menuGestion; //Menu para la gestion de cuentas
    private JMenuItem cargarItem, guardarItem, vaciarItem, cargarTestItem, panelVerItem, panelInsertarItem, panelUnoaUnoItem ; // Elementos del menú
    private Lista<Cuenta> listaCuentas; // Lista de cuentas
    private PanelVisual panelVisual; // Panel para mostrar las cuentas a la vez con JList
    private PanelUnoaUno panelUnoaUno;
    private PanelInsercion panelInsercion; // Panel para insertar cuentas

    public AplicacionPrincipal() {
        setTitle("Aplicación Bancaria"); // Título de la ventana
        setSize(800, 300); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cierre de la aplicación
        setLayout(new BorderLayout()); // Layout de la aplicación

        // Inicializar la lista de cuentas
        listaCuentas = new Lista<>();

        // Crear el menú
        menuBar = new JMenuBar(); // Inicializar la barra de menú
        menu = new JMenu("Opciones"); // Crear el menú opciones
        
        menuGestion= new JMenu("Gestion de cuentas"); //crear menu de gestion de cuentas
        

        // Crear elementos del menú opciones
        cargarItem = new JMenuItem("Cargar desde archivo");
        guardarItem = new JMenuItem("Guardar en archivo");
        vaciarItem = new JMenuItem("Vaciar lista");
        cargarTestItem = new JMenuItem("Cargar cuentas de prueba");
        
        // Crear elementos del menú gestion de cuentas
        panelVerItem = new JMenuItem("Ver");
        panelUnoaUnoItem = new JMenuItem("Ver uno a uno");
        panelInsertarItem = new JMenuItem("Insertar nueva cuenta");
        


        // Agregar elementos al menú
        menu.add(cargarItem);
        menu.add(guardarItem);
        menu.add(vaciarItem);
        menu.add(cargarTestItem);
        
        // Agregar elementos al menú de gestion
        menuGestion.add(panelVerItem);
        menuGestion.add(panelUnoaUnoItem);
        menuGestion.add(panelInsertarItem);
        
        menuBar.add(menu); // Añadir menú a la barra
        menuBar.add(menuGestion); // Añadir menú gestion a la barra
        
        setJMenuBar(menuBar); // Establecer la barra de menú en la ventana
        

        // Instanciar los paneles, pasándoles la lista de cuentas
        panelVisual = new PanelVisual(listaCuentas);
        panelUnoaUno = new PanelUnoaUno(listaCuentas);
        panelInsercion = new PanelInsercion(listaCuentas, panelVisual);
        
        
               
        // Creamos el panel principal donde mostraremos los otros paneles
        panelPrinci = new JPanel();
        panelPrinci.setLayout(new CardLayout()); // Usamos un CardLayout para cambiar entre paneles
        panelPrinci.add(panelVisual, "Ver");
        panelPrinci.add(panelUnoaUno, "Ver uno a uno");
        panelPrinci.add(panelInsercion, "Insertar");
        
         // Añadimos el panel principal al JFrame
        add(panelPrinci, BorderLayout.CENTER);
        
        /*
        // Añadir paneles al frame
        add(panelVisual, BorderLayout.CENTER);
        add(panelInsercion, BorderLayout.SOUTH);*/

        // Asignar los listeners a cada ítem de menú
        cargarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarDesdeArchivo(); // Llamar al método para cargar cuentas
            }
        });

        guardarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarEnArchivo(); // Llamar al método para guardar cuentas
            }
        });

        vaciarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vaciarLista(); // Llamar al método para vaciar la lista de cuentas
            }
        });

        cargarTestItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarCuentasDePrueba(); // Llamar al método para cargar cuentas de prueba
            }
        });
        
        panelVerItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Ver");
            }
        });

        panelUnoaUnoItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Ver uno a uno");
            }
        });

        panelInsertarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanel("Insertar");
            }
        });
    }
    private void mostrarPanel(String nombrePanel) {
        CardLayout layout = (CardLayout) panelPrinci.getLayout();
        layout.show(panelPrinci, nombrePanel); // Cambiamos el panel que se muestra
    }

    // Método para cargar cuentas desde un archivo
    private void cargarDesdeArchivo() {
        JFileChooser fileChooser = new JFileChooser(); // Crear un selector de archivos
        int returnValue = fileChooser.showOpenDialog(this); // Mostrar el diálogo de apertura
        if (returnValue == JFileChooser.APPROVE_OPTION) { // Verificar si se seleccionó un archivo
            File selectedFile = fileChooser.getSelectedFile(); // Obtener el archivo seleccionado
            try {
                // Llamar al método de GestorArchivos para cargar la lista de cuentas
                listaCuentas = GestorArchivos.cargarDesdeArchivo(selectedFile.getAbsolutePath());
                
                
                // Reiniciar el índice de la lista para comenzar desde la primera cuenta 
                 listaCuentas.lista();
                 //listaCuentas.imprimirEstadoLista();
                
                // Actualiza los paneles con la nueva lista
                 panelUnoaUno.setListaCuentas(listaCuentas);
                
                
                // Refresca la visualización en ambos paneles
                panelUnoaUno.actualizarPantalla();
                //panelUnoaUno.actualizarBotones();
                panelVisual.cargarLista(listaCuentas);
                
                
                JOptionPane.showMessageDialog(this, "Cuentas cargadas con éxito."); // Mensaje de éxito
            } catch (IOException | ClassNotFoundException ex) {
                // Mostrar mensaje de error en caso de excepción
                JOptionPane.showMessageDialog(this, "Error al cargar cuentas: " + ex.getMessage());
            }
        }
    }

    // Método para guardar la lista de cuentas en un archivo
    private void guardarEnArchivo() {
        JFileChooser fileChooser = new JFileChooser(); // Crear un selector de archivos
        int returnValue = fileChooser.showSaveDialog(this); // Mostrar el diálogo de guardar
        if (returnValue == JFileChooser.APPROVE_OPTION) { // Verificar si se seleccionó un archivo
            File selectedFile = fileChooser.getSelectedFile(); // Obtener el archivo seleccionado
            try {
                // Llamar al método de GestorArchivos para guardar la lista de cuentas
                GestorArchivos.guardarEnArchivo(listaCuentas, selectedFile.getAbsolutePath());
                JOptionPane.showMessageDialog(this, "Cuentas guardadas con éxito."); // Mensaje de éxito
            } catch (IOException ex) {
                // Mostrar mensaje de error en caso de excepción
                JOptionPane.showMessageDialog(this, "Error al guardar cuentas: " + ex.getMessage());
            }
        }
    }

    // Método para vaciar la lista de cuentas
    private void vaciarLista() {
        listaCuentas.vaciar(); // Vaciar la lista de cuentas
        panelVisual.vaciarLista(); // Vaciar también la visualización
        panelUnoaUno.vaciarLista();
        //panelUnoaUno.actualizarPantalla(); // Actualizar la visualización
        JOptionPane.showMessageDialog(this, "Lista de cuentas vaciada."); // Mensaje de éxito
    }

    // Método para cargar cuentas de prueba
    private void cargarCuentasDePrueba() {
        // Limpiar la lista actual
        listaCuentas.vaciar();
        
        // Crear algunas cuentas de prueba
        try {
            // Crear cuentas de ahorro
            Cuenta cuentaAhorro1 = new CuentaAhorro(1, "Juan Pérez", 1500.0, 0.05, new Date(), 12, 6 );
            Cuenta cuentaAhorro2 = new CuentaAhorro(2, "María Gómez", 2500.0, 0.03,new Date(), 6, 5);
            
            // Crear cuentas corrientes
            Cuenta cuentaCorriente1 = new CuentaCorriente(3, "Pedro López", 3000.0, 100.0, new Date(), 10.0,"Comision por estudio");
            Cuenta cuentaCorriente2 = new CuentaCorriente(4, "Ana Fernández", 2000.0, 200.0, new Date(), 5.0, "Comision por apertura");

            // Insertar cuentas en la lista
            listaCuentas.insertar(cuentaAhorro1);
            listaCuentas.insertar(cuentaAhorro2);
            listaCuentas.insertar(cuentaCorriente1);
            listaCuentas.insertar(cuentaCorriente2);

            // Actualizar la visualización
            panelUnoaUno.actualizarPantalla();
            panelVisual.cargarLista(listaCuentas);
            
            // Mostrar mensaje de éxito
            JOptionPane.showMessageDialog(this, "Cuentas de prueba cargadas con éxito.");
        } catch (Exception ex) {
            // Mostrar mensaje de error en caso de excepción
            JOptionPane.showMessageDialog(this, "Error al cargar cuentas de prueba: " + ex.getMessage());
        }
    }

    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
         // Creamos una instancia de la ventana principal
        AplicacionPrincipal ventana = new AplicacionPrincipal();

        // Hacemos visible la ventana
        ventana.setVisible(true); 
    }
    
}   



