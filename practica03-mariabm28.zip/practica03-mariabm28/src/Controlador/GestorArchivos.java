/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import Controlador.Lista;
import java.io.EOFException;
import java.io.Serializable;
/**
 *
 * @author Maria
 */
public class GestorArchivos {
    // Método para guardar una lista de objetos en un archivo
    public static <T extends Serializable> void guardarEnArchivo(Lista<T> lista, String nombreArchivo) throws IOException {
        // El try-with-resources garantiza que el archivo se cierra automáticamente
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
             Nodo<T> actual = lista.getInicio(); // Obtenemos el primer nodo
            while (actual != null) {
                out.writeObject(actual.getDato()); // Guardamos cada objeto en el archivo
                actual = actual.getSiguiente(); // Avanzamos al siguiente nodo
            }
        } 
    }
            
    

    // Método para cargar una lista de objetos desde un archivo
   public static <T extends Serializable> Lista<T> cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        Lista<T> lista = new Lista<>(); // Creamos una nueva lista para almacenar los objetos cargados
        // El try-with-resources garantiza que el archivo se cierra automáticamente
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
                  while (true) {
                try {
                    T obj = (T) in.readObject(); // Leemos cada objeto del archivo
                    lista.insertar(obj); // Insertamos el objeto en la lista
                } catch (EOFException e) {
                    break; // Fin del archivo alcanzado
                }
            }
        }
        return lista; // Retornamos la lista con los objetos cargados
    }
      
}
