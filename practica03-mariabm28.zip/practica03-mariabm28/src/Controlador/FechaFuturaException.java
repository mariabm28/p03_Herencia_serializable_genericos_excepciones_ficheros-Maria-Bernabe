/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Maria
 */
public class FechaFuturaException extends Exception{
    
    public FechaFuturaException(String mensaje){
        super(mensaje);
    }
    public static boolean esFechaFutura(Date fecha) {
        
        // Instancia de Calendar para fecha de apertura
        Calendar apertura = Calendar.getInstance();
        apertura.setTime(fecha); // Obtener el tiempo de la fecha de apertura

        // Instancia de Calendar para fecha actual
        Calendar actual = Calendar.getInstance();
        return apertura.after(actual);
        
       
    }
}
