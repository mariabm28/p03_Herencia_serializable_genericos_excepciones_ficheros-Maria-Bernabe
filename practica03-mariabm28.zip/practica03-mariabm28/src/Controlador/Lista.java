/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author Maria
 */
public class Lista<T> {
    private Nodo<T> inicio;  // Primer nodo de la lista
    private Nodo<T> fin;    // Último nodo de la lista
    private Nodo<T> actual;  // Referencia al nodo actual (para avanzar o retroceder)

    public Lista() {
        this.inicio = null;
        this.fin = null;
        this.actual = null;
    }
    
    //Para obtener el primer nodo
    public Nodo<T> getInicio() {
        return inicio;
    }

    public void setInicio(Nodo<T> inicio) {
        this.inicio = inicio;
    }

    //Para obtener el ultimo nodo
    public Nodo<T> getFin() {
        return fin;
    }

    public void setFin(Nodo<T> fin) {
        this.fin = fin;
    }
    
      // Método para agregar un nuevo nodo al final de la lista
    public void insertar(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (inicio == null) {
            inicio = nuevo;
            fin = nuevo;
            actual = nuevo;  // Inicializamos el nodo actual en el inicio
        } else {
            fin.setSiguiente(nuevo);  // Conectamos el último nodo con el nuevo nodo
            nuevo.setAnterior(fin);   // El nuevo nodo apunta a al antiguo fin
            fin = nuevo;              // El nuevo nodo se convierte en el ultimo
        }
    }
    
     // Método para avanzar al siguiente nodo
    public void avanzar() {
        if (actual != null && actual.getSiguiente() != null) {
            actual = actual.getSiguiente();  // Avanza al siguiente nodo
        }
    }
    
    // Método para retroceder al nodo anterior
    public void retroceder(){
    
        if(actual != null && actual.getDato()!=null){
            actual=actual.getAnterior(); //Retroce al nodo anterior
        }
    }
    
    // Método para verificar si el nodo actual es el primero
    public boolean esPrimero(){
         return actual == inicio; //Retorna true si el nodo actual es el inicio
    }
    
    // Método para verificar si el nodo actual es el último
    public boolean esUltimo() {
        return actual == fin;  // Retorna true si el nodo actual es el fin
    }
    
     // Método para verificar si la lista está vacía
    public boolean esVacia() {
        return inicio == null; //Devuelve true si inicio es null, es decir no hay nada
    }
    
     // Método para leer el dato del nodo actual
    public T leer() {
        if (actual != null) {
            return actual.getDato();  // Devuelve el dato almacenado en el nodo actual
        }
        return null;  // Devuelve null si no hay nodo actual
    }
    
    // Método para reiniciar la lista (coloca el nodo actual en el inicio)
    public void lista() {
        actual = inicio;  // Restablece el nodo actual al primer nodo (inicio)
    }
    
    // Método para vaciar la lista
    public void vaciar() {
       // Establecemos inicio y fin a null para eliminar la referencia a todos los nodos
        inicio = null; // Eliminar referencia al primer nodo
        fin = null;    // Eliminar referencia al último nodo
        actual = null; // Restablecer el nodo actual
        
    }
    
    public void imprimirEstadoLista() {
    System.out.println("Estado de la lista:");
    Nodo<T> temp = inicio;
    while (temp != null) {
        System.out.print(temp.getDato() + " -> ");
        temp = temp.getSiguiente();
    }
    System.out.println("null");

    System.out.println("Nodo actual: " + (actual != null ? actual.getDato() : "null"));
    System.out.println("Nodo siguiente: " + (actual.getSiguiente() != null ? actual.getSiguiente().getDato() : "null"));
}

    
    
}
